import cv2
import time
import ExerciseCondition as EC

Exercise_type = {1: 'pushup', 2: 'barbellCurl', 3: 'squat'}
Routine_type = {'Legs': [3, 1, 2], 'Arms': [1, 3, 2]}
Routine = 'Legs'

# 'pose/squat.mp4' pose/Boy1920x1080.mp4 pose/pushup.mp4 pose/pushupvideo.mp4 pose/barbellcurl2.mp4
# pose/SquatsideView.mp4 pose/squat2
cap = cv2.VideoCapture('pose/squat2.mp4')
fps = round(cap.get(cv2.CAP_PROP_FPS))
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

delay = round(1000 / fps)


# codec = cv2.VideoWriter_fourcc(*"MJPG")
# writer = cv2.VideoWriter('pose/webcam_output.avi', codec, fps, (width, height))

detector = EC.ExerciseType(width,height,fps)

time.sleep(2)
start = time.time()
idx = 0

while True:
    success, img = cap.read()
    # img = cv2.resize(img, (width*2, height*2))
    # img = cv2.rotate(img, cv2.cv2.ROTATE_90_COUNTERCLOCKWISE)
    # img = cv2.flip(img, 0)
    # img = cv2.flip(img, 1)

    Exercise = Routine_type[Routine]

    img = detector.findPose(img, draw=False)
    lmList = detector.findPosition(img, draw=False)

    if len(lmList) != 0:
        current = time.time()-start
        count = detector.SelectExerciseMode(img, Exercise_type[Exercise[idx]])
        if (int(current) == 25) | (count == 10):
            idx += 1
            start = time.time()

    cv2.rectangle(img, (0, height - 200), (150, height),
                  (0, 255, 0), cv2.FILLED)
    cv2.putText(img, '{:.1f}'.format(current), (15, height-75), cv2.FONT_HERSHEY_PLAIN, 5,
                (255, 0, 0), 5)
    cv2.putText(img, Exercise_type[Exercise[idx]], (15+150, height-50), cv2.FONT_HERSHEY_PLAIN, 5,
                (0, 0, 255), 5)

    cv2.imshow('image', img)
    if cv2.waitKey(2) == 27:
        break
    # detector.VideoSave(writer, img) ############

# writer.release()
cap.release()
cv2.destroyAllWindows()
